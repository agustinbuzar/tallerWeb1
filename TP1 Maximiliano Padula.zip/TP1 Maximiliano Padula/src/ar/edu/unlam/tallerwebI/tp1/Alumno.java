package ar.edu.unlam.tallerwebI.tp1;

public class Alumno {
	
	private Integer primerparcial;
	private Integer segundoparcial;
	
	
	//Calificar primer Parcial
	public void calificarPrimerParcial(Integer nota) {  
		
		primerparcial=nota;
		
	}
	//Obtener calificacion primer Parcial
	public Integer getPrimerParcial() {
		
		return this.primerparcial;
	}
	
	
	//Calificar segundo Parcial
	public void calificarSegundoParcial(Integer nota) {
		
		segundoparcial=nota;
		
	}
	//Obtener calificacion segundo Parcial
	public Integer getSegundoParcial() {
		
		return this.segundoparcial;
	}
	
	//El alumno aprueba SOLO si su promedio y sus notas son mayores a 4//
	public boolean estaAprobado() { 
			
		boolean aprobo;
			
		if(primerparcial>=4 && segundoparcial>=4)
			
			aprobo=true;
				
		else
			aprobo = false;
		
		return aprobo;
	}
	
	//El alumno promociona SOLO si su promedio y sus notas son mayores o iguales a 7//
	
	public boolean estaPromocionado() {
			
		boolean promociono;
			
		if(primerparcial >=7 && segundoparcial >=7)

	          promociono=true;
					
			else
			  promociono=false;
			
		return promociono;
		}
	
	
}


